package fp.trabajo;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.util.List;
import java.util.stream.Stream;

import fp.trabajo.Covid;
import fp.utiles.Ficheros;
import fp.trabajo.Vacunas;

public class FactoriaCovids {
	
	public Covid leeCovids(String linea){
		Covid res= null;
		try {
			Stream<Covid> sc= Files.lines(Paths.get(linea))
			.skip(1)
			.map(FactoriaCovids::parsearCovid);
			res= new Covid(sc);
		}catch(IOException e){
			System.out.println("No se ha podido encontrar el archivo"+ linea);
			e.printStackTrace();
		}
		return res;
		}
	private static Covid parsearCovid(String lineaCSV) {
		String[] campos= lineaCSV.split(",");
		Checkers.check("La linea debe contener 7 campos", campos.length==7);
		Integer casos_totales_UK=Integer.parseInt(campos[0].trim());
		Integer casos_Inglaterra=Integer.parseInt(campos[1].trim());
		Vacunas vacuna=Enumerate.parseEnum(campos[2].trim());
		String sintomas=campos[3].trim();
		Boolean vacunado=Boolean.parseBoolean(campos[4].trim());
		LocalDate fecha_vacunacion=LocalDate.parse(campos[5].trim());
		String ciudad_vacunacion= campos[6].trim();
		
		return null;
		
	}
}
	

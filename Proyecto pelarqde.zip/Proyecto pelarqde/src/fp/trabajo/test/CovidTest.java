package fp.trabajo.test;

import java.time.LocalDate;

import fp.trabajo.Covid;
import fp.trabajo.Vacunas;
import fp.trabajo.FactoriaCovids;

public class CovidTest {

	
	public static void main(String[] args) {
		Integer casos_totales_UK= 32456;
		Integer casos_Inglaterra= 456;
		String sintomas= "Fiebre";
		String ciudad_vacunacion="Liverpool";
		Boolean vacunado=false;
		LocalDate fecha_vacunacion= LocalDate.of(2020, 8,23);
		Covid c1= new Covid(casos_totales_UK, casos_Inglaterra, Vacunas.PFIZER, sintomas, ciudad_vacunacion, vacunado, 
				fecha_vacunacion);
		System.out.println(c1);
		
		
	}
	
	public static void main(String[] args) {
		Integer casos_totales_UK= 76389567;
		Integer casos_Inglaterra= 986541;
		String sintomas= "Tos";
		String ciudad_vacunacion="Londres";
		Boolean vacunado=False;
		LocalDate fecha_vacunacion= LocalDate.of(2020, 6,23);
		Covid c1= new Covid(casos_totales_UK, casos_Inglaterra, Vacunas.ASTRAZENECA, sintomas, ciudad_vacunacion, vacunado, 
				fecha_vacunacion);
		System.out.println(c2);
		
		
	}
	FactoriaCovids f= new FactoriaCovids("FP", "datos/MOCK_DATA(2).csv");
	
	System.out.println("Datos cargados. Probando tratamientos secuenciales.");

	System.out.println("Sintomas" + c1.getSintomas());


	System.out.println("Comparaci�n por  " + c1.compareTo(C2));

	System.out.print("Hash Code " + c1.hashCode());
	System.out.print("Equals" + c2.equals(c1));

	System.out.println("a�adir Covid " + c.a�adirCovid(c1));
	System.out.println(" Calcular sintomas por ciudad" + c1.getSintomasPorCiudad("Resfriado", "Liverpool"));
	System.out.println("Media de contagios"+ c2.MediaContagiosMinimosPorCiudad("Luton"));
	System.out.println("Vacunas por ciudad"+ c1.VacunasPorCiudad("Londres"));
	System.out.println("Leer linea  fichero" + c1.parsearCovid());
	System.out.println("Leer fichero" + c2.leeCovid(MOCK_DATA(2).csv));

	
}

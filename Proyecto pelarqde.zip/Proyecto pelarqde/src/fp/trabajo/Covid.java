package fp.trabajo;
import java.time.LocalDate;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import com.sun.jndi.rmi.registry.ReferenceWrapper_Stub;
public class Covid {
	
	private Integer casos_totales_UK;
	private Integer casos_Inglaterra;
	private Vacunas vacuna;
	private String sintomas;
	private boolean vacunado;
	private LocalDate fecha_vacunacion;
	private String ciudad_vacunacion;
	private HashSet<Covid> covids;
	
	public Covid(Integer casos_totales_UK, Integer casos_Inglaterra, Vacunas vacuna, String sintomas,
			boolean vacunado, LocalDate fecha_vacunacion, String ciudad_vacunacion){
		
		if(fecha_vacunacion.isBefore(LocalDate.ofYearDay(2020, 135))){
			throw new IllegalArgumentException("La fecha de vacunacion no puede ser antes que abril de 2020");
		}
		
		if(casos_totales_UK <= 0) {
			throw new IllegalArgumentException("Los casos deben ser mayores que 0");
		}
		this.casos_totales_UK= casos_totales_UK;
		this.casos_Inglaterra=casos_Inglaterra;
		this.vacuna=vacuna;
		this.sintomas=sintomas;
		this.vacunado=vacunado;
		this.fecha_vacunacion=fecha_vacunacion;
		this.ciudad_vacunacion=ciudad_vacunacion;
		}

	
		// TODO Auto-generated constructor stub



	public Integer getCasos_totales_UK() {
		return casos_totales_UK;
	}

	public void setCasos_totales_UK(Integer casos_totales_UK) {
		this.casos_totales_UK = casos_totales_UK;
	}

	public Integer getCasos_Inglaterra() {
		return casos_Inglaterra;
	}

	public void setCasos_Inglaterra(Integer casos_Inglaterra) {
		this.casos_Inglaterra = casos_Inglaterra;
	}
	
	public Vacunas getVacuna() {
		return vacuna;
	}

	public void setVacuna(Vacunas vacuna) {
		this.vacuna = vacuna;
	}

	public String getSintomas() {
		return sintomas;
	}

	public void setSintomas(String sintomas) {
		this.sintomas = sintomas;
	}

	public boolean isVacunado() {
		return vacunado;
	}

	public void setVacunado(boolean vacunado) {
		this.vacunado = vacunado;
	}

	public LocalDate getFecha_vacunacion() {
		return fecha_vacunacion;
	}

	public void setFecha_vacunacion(LocalDate fecha_vacunacion) {
		this.fecha_vacunacion = fecha_vacunacion;
	}

	public String getCiudad_vacunacion() {
		return ciudad_vacunacion;
	}

	public void setCiudad_vacunacion(String ciudad_vacunacion) {
		this.ciudad_vacunacion = ciudad_vacunacion;
	}
	


	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((casos_Inglaterra == null) ? 0 : casos_Inglaterra.hashCode());
		result = prime * result + ((casos_totales_UK == null) ? 0 : casos_totales_UK.hashCode());
		result = prime * result + ((ciudad_vacunacion == null) ? 0 : ciudad_vacunacion.hashCode());
		result = prime * result + ((fecha_vacunacion == null) ? 0 : fecha_vacunacion.hashCode());
		result = prime * result + ((sintomas == null) ? 0 : sintomas.hashCode());
		result = prime * result + ((vacuna == null) ? 0 : vacuna.hashCode());
		result = prime * result + (vacunado ? 1231 : 1237);
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Covid other = (Covid) obj;
		if (casos_Inglaterra == null) {
			if (other.casos_Inglaterra != null)
				return false;
		} else if (!casos_Inglaterra.equals(other.casos_Inglaterra))
			return false;
		if (casos_totales_UK == null) {
			if (other.casos_totales_UK != null)
				return false;
		} else if (!casos_totales_UK.equals(other.casos_totales_UK))
			return false;
		if (ciudad_vacunacion == null) {
			if (other.ciudad_vacunacion != null)
				return false;
		} else if (!ciudad_vacunacion.equals(other.ciudad_vacunacion))
			return false;
		if (fecha_vacunacion == null) {
			if (other.fecha_vacunacion != null)
				return false;
		} else if (!fecha_vacunacion.equals(other.fecha_vacunacion))
			return false;
		if (sintomas == null) {
			if (other.sintomas != null)
				return false;
		} else if (!sintomas.equals(other.sintomas))
			return false;
		if (vacuna != other.vacuna)
			return false;
		if (vacunado != other.vacunado)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Covid [casos_totales_UK=" + casos_totales_UK + ", casos_Inglaterra=" + casos_Inglaterra + ", vacuna="
				+ vacuna + ", sintomas=" + sintomas + ", vacunado=" + vacunado + ", fecha_vacunacion="
				+ fecha_vacunacion + ", ciudad_vacunacion=" + ciudad_vacunacion + "]";
	}
	
	public Covid(){
		this.covids= new HashSet<Covid>();
	}
	
	public void a�adirCovid(Covid covid){
		this.covids.add(covid);
	}
	
	public Integer getNumeroCovids(Covid covids) {
		return this.covids.size();
	}
	
	public boolean existeVacunaEnCiudad(Vacunas v,String ciudad_vacunacion){
		return covids.stream().allMatch(r->r.getCiudad_vacunacion().equals(ciudad_vacunacion) && r.getVacuna().equals(v));
	}
	public boolean getSintomasPorCiudad(String s, String ciudad){
		return covids.stream().filter(r->r.getCiudad_vacunacion().equals(ciudad)).anyMatch(r -> s.contains(r.getSintomas()));
	}
	public Integer ContagiosInglaterraSintomasVacuna(String s, Vacunas v){
		return covids.stream().filter(r->r.getSintomas().equals(s)&& r.getVacuna()
				.equals(v)).mapToInt(r-> r.getCasos_Inglaterra()).max().getAsInt();
	}
	public Double MediaContagiosMinimosPorCiudad(String c) {
		 return covids.stream().filter(r->r.getCiudad_vacunacion().equals(c))
				.mapToDouble(r -> r.getCasos_totales_UK()).min().average().getAsDouble();
	}
	public Set<LocalDate> FechasNCasosUKMayorMediaMinimaCiudad(String ciudad, Integer casos, Integer n){
		return covids.stream().filter(r -> r.getCiudad_vacunacion().equals(ciudad) &&
				r.getCasos_totales_UK().equals(casos).sorted(Comparator.comparing(Covid::getCasos_totales_UK).reversed())
						.map(r -> r.getFecha_vacunacion()).distinct().limit(n).collect(Collectors.toSet());
	}
	public Map<String, List<Covid>> VacunasPorCiudad(){
		return covids.stream().collect(Collectors.groupingBy(Covid::getCiudad_vacunacion));
	}
	public Map<Integer, List<Covid>> SintomasPorCasosInlgaterra(){
	return covids.stream().collect(Collectors.groupingBy(Covid::getCasos_Inglaterra));
	}
	
	public Map<String, List<Covid>> CiudadesPorVacunaYFechadeVacunacion(Vacunas v, LocalDate fecha){
		return covids.stream().filter(r -> r.getVacuna().equals(v) && r.getFecha_vacunacion()
				.equals(fecha)).collect(Collectors.groupingByConcurrent(Covid::getCiudad_vacunacion));
	}
}

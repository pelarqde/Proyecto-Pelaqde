package fp.trabajo;

public enum Vacunas {
	
ASTRAZENECA, PFIZER, MODERNA
}

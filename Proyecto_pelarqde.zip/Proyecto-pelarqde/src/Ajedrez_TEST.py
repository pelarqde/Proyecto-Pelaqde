'''
Created on 20 dic. 2020

@author: arque
'''

from Ajedrez import *


def test_lee_fichero(fichero):
 print("El juego que busca es...", fichero[0], )
 print("Los jugadores blancas son:", fichero[:6])
 print("Los jugadores negros son:", fichero[:8])
 
 def test_numero_de_turnos_e_incremento_de_tiempo(juegos):
     print("La lista de juegos por turno y tiempo es", info)
     
def test_lista_aperturas_echo(juegos):
      print("Lista de aperturas...", list({j.opening_echo for j in juegos}))
       
def test_numero_jugadores_blancos_distintos(juegos):
    print("Los jugadores que juegan blancas son", len(sorted(j.white_player_id for j in juegos)))

def test_juego_por_numero_de_turnos(juegos):
    numero_de_turnos=46
    print("El juego con el numero de turnos seleccionado", 
          numero_de_turnos,  "es..",juego_por_numero_de_turnos(juegos, numero_de_turnos))
    
def test_estadisticas_negras_si_ganan_negras(juegos, ganador):
    ganador=False
    print("Las jugadores negras tienen estos datos ganando"
          , estadisticas_negras_si_ganan_negras(juegos, ganador))
    
def test_maximos_movimientos_por_apertura(juegos, opening_name):
    opening_name=1094
    print("Los movimientos maximos con la apertura", opening_name, "son", 
           maximos_movimientos_por_apertura(juegos, opening_name)) 
    
def test_media_numero_de_turnos(juegos, fecha_de_inicio):
    fecha_de_inicio="15/09/2016"
    print("En esa fecha",fecha_de_inicio,
           "los movimientos fueron", media_numero_de_turnos(juegos, fecha_de_inicio))
    
def test_turnos_jugadores_blancos_por_rating(juegos, rating):
    rating=78
    print("Los turnos de jugadores blancos con el rating", rating, 
          "fueron", turnos_jugadores_blancos_por_rating(juegos, rating))   
         
def test_lista_de_jugadores_negros_por_apertura(juegos,apertura):
    apertura=1300
    print("Los jugadores negros con la apertura", apertura, "son", 
          lista_de_jugadores_negros_por_apertura(juegos, apertura))  
            
def test_top_jugadores_blancos_por_turnos(juegos, jugador_blanco, n=3):
    turnos=65
    print("Los tres jugadores blancos con los turnos", turnos, "son", 
          top_jugadores_blancos_por_turnos(juegos, jugador_blanco, n=3))    
'''
Created on 17 dic. 2020

@author: arque
'''

from conda.common._logic import FALSE
from tornado.ioloop import PeriodicCallback
from pygments.lexers._cocoa_builtins import res

''' Titulo: Ajedrez'''

import csv
from matplotlib import pyplot as plt
import datetime

def leer_fichero(fichero):
    with open(fichero, 'r', encoding= 'utf-8') as f:
        lector=csv.reader(f)
        next(lector)
        juegos=[(id_game, bool(rated), datetime.strptime(start_time, '%H/%M/%s').hour(),
        int(number_of_turns), game_status, bool(winner), time_increment, white_player_id, int(white_player_rating),
        black_player_id, int(black_player_rating), notation_chess, opening_echo, opening_name,
        opening_ply) for id_game, rated, start_time, end_time, number_of_turns, 
        game_status, winner, time_increment, white_player_id, white_player_rating,
        black_player_id, black_player_rating, notation_chess, opening_echo,
        opening_name, opening_ply in lector]
return juegos
 
def numero_de_turnos_e_incremento_de_tiempo(juegos):
    info= sorted({j.number_of_turns for j in juegos}), sorted({j.time_increment for j in juegos})
    return info

def lista_aperturas_echo(juegos):
    return list({j.opening_echo for j in juegos})

def numero_jugadores_blancos_distintos(juegos):
    return len(sorted(j.white_player_id for j in juegos))

def juego_por_numero_de_turnos(juegos, number_of_turns):
    return sorted(j.game_id for j in juegos if j.number_of_turns==number_of_turns)
 
def estadisticas_negras_si_ganan_negras(juegos, ganador):
    negras=sorted(([j.number_of_turns for j in juegos]), 
    ([j.black_player_rating for j in juegos], [j.black_player_id for j in juegos])
    if ((ganador==j.winner)==False):
        negras=negras
    else:
    negras=0
        
    return negras
 
def maximos_movimientos_por_apertura(juegos, opening_name):
    juegos=[juego in juegos if(opening_name==juego.opening_name)]
    return max(juego, key = lambda juego:juego.opening_name)

def media_numero_de_turnos(juegos, fecha_de_inicio):
    turnos=[juego.number_of_turns for juego in juegos if fecha_de_inicio==juego.start_time]
    media=0
    if len(turnos)>0:
        media=sum(turnos)/len(turnos)
    return turnos 
 
def turnos_jugadores_blancos_por_rating(juegos, rating):
    dicc={}
    for juego in juegos:
        if juego.white_player_rating==rating:
            if juego.white_player_id in dicc:
                dicc[juego.white_player_id] += number_of_turns(juego) 
            else:
                dicc[juego.white_player_id] = number_of_turns(juego)     
    return dicc

def lista_de_jugadores_negros_por_apertura(juegos, apertura):
    dicc=juego_por_apertura(juegos, apertura)
    res=dict()
    for opening_name, black_player_id in dicc.items():
        jugadores_negros=sorted(black_player_id, key=lambda, juegos:opening_name).reverse()
    return res     

def juegos_por_apertura(juegos, apertura):
    res=dict()
    for juego in juegos:
        if juego.opening_name==apertura:
            if juego.opening_name in res:
                res[juego.opening_name].append(juego)
            else:
                res[juego.opening_name]=[juego]
    return res            
    
    
def top_jugadores_blancos_por_turnos(juegos, jugador_blanco, n=3):
    dicc=turnos_jugadores_blancos_por_rating(juegos, rating):
    res=dict()
    for white_player_id, number_of turns in dicc.items():
        jugadores_blancos=sorted(white_player_id, key=lambda juegos:number_of_turns).reverse()
        res[number_of_turns]=numero_jugadores_blancos
        turnos=list[res.keys]
        return turnos[n]
        
Este proyecto va sobre datos de ajedrez, asi como el nombre del juego, los jugadores blancos con sus victorias, 
las negras, las aperturas, los turnos totales, etc.